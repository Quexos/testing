package com.maceskins;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MaceSkinsScreen extends Screen {

    private static final int BTN_W  = 200;
    private static final int BTN_H  = 24;
    private static final int GAP    = 8;
    // Total rows: 1 (title gap) + 1 (original) + N skins + 1 (close)
    private static final int ROWS   = 1 + SkinManager.SKIN_IDS.length + 1;

    public MaceSkinsScreen() {
        super(Text.literal("✦ Mace Skins ✦"));
    }

    @Override
    protected void init() {
        int cx     = this.width  / 2;
        int totalH = ROWS * (BTN_H + GAP);
        int startY = (this.height - totalH) / 2;

        // ── Original (vanilla) ──────────────────────────────────
        boolean isDefault = SkinManager.getCurrentSkin() == null;
        addDrawableChild(
            ButtonWidget.builder(
                Text.literal(isDefault ? "✓ ⚔  Original (Gold)" : "⚔  Original (Gold)"),
                btn -> { SkinManager.selectDefault(); close(); }
            )
            .dimensions(cx - BTN_W / 2, startY, BTN_W, BTN_H)
            .build()
        );

        // ── One button per skin ──────────────────────────────────
        for (int i = 0; i < SkinManager.SKIN_IDS.length; i++) {
            final String id   = SkinManager.SKIN_IDS[i];
            final String name = SkinManager.SKIN_NAMES[i];
            boolean active    = id.equals(SkinManager.getCurrentSkin());

            addDrawableChild(
                ButtonWidget.builder(
                    Text.literal(active ? "✓ " + name : name),
                    btn -> { SkinManager.selectSkin(id); close(); }
                )
                .dimensions(cx - BTN_W / 2, startY + (i + 1) * (BTN_H + GAP), BTN_W, BTN_H)
                .build()
            );
        }

        // ── Close ────────────────────────────────────────────────
        addDrawableChild(
            ButtonWidget.builder(
                Text.literal("Close  [Esc]"),
                btn -> close()
            )
            .dimensions(cx - BTN_W / 2, startY + ROWS * (BTN_H + GAP), BTN_W, BTN_H)
            .build()
        );
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);

        int titleY = (this.height - (ROWS + 1) * (BTN_H + GAP)) / 2 - 24;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, titleY, 0xFFFFFF);

        ctx.drawCenteredTextWithShadow(
            this.textRenderer,
            Text.literal("Select a skin to apply — changes take ~1 second"),
            this.width / 2, titleY + 14, 0x888888
        );

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the game running behind the menu
    }
}
