package com.maceskins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;

import java.util.ArrayList;
import java.util.List;

public class SkinManager {

    // Skin IDs — must match the folder names under resourcepacks/maceskins/
    public static final String[] SKIN_IDS   = { "petals",   "lightning", "white" };
    public static final String[] SKIN_NAMES = { "🌸 Petals", "⚡ Lightning", "🤍 White" };

    private static String currentSkin = null; // null = vanilla/default

    public static String getCurrentSkin() {
        return currentSkin;
    }

    /** Switch to one of the custom skins and reload resources. */
    public static void selectSkin(String skinId) {
        currentSkin = skinId;
        apply();
    }

    /** Revert to the original vanilla mace texture. */
    public static void selectDefault() {
        currentSkin = null;
        apply();
    }

    private static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;

        ResourcePackManager rpm = mc.getResourcePackManager();

        // Refresh the list of known packs so our built-in ones are discovered
        rpm.scanPacks();

        // Build the new enabled-pack list, preserving all non-maceskins packs
        List<String> enabled = new ArrayList<>(rpm.getEnabledNames());

        // Remove every maceskins skin pack that might already be active
        for (String id : SKIN_IDS) {
            enabled.remove("maceskins:" + id);
        }

        // Add the newly chosen skin (if not reverting to default)
        if (currentSkin != null) {
            enabled.add("maceskins:" + currentSkin);
        }

        // Reload with the updated pack list — this is async; game stays running
        mc.reloadResources(enabled);
    }
}
