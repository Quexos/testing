package com.maceskins;

import net.fabricmc.api.ModInitializer;

public class MaceSkins implements ModInitializer {
    public static final String MOD_ID = "maceskins";

    @Override
    public void onInitialize() {
        // Nothing needed server-side — this is a client-only mod
    }
}
