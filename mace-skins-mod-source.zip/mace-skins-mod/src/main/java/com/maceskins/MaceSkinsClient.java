package com.maceskins;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MaceSkinsClient implements ClientModInitializer {

    public static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {

        // ── 1. Register the M keybinding ────────────────────────
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.maceskins.open_menu",          // translation key
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_M,                    // default: M
            "category.maceskins"                // keybind category name
        ));

        // ── 2. Register each skin as a built-in resource pack ───
        //    The pack files live at:
        //    src/main/resources/resourcepacks/maceskins/<skinId>/
        //    Inside the jar this becomes:
        //    resourcepacks/maceskins/<skinId>/assets/minecraft/textures/item/mace.png
        var container = FabricLoader.getInstance()
            .getModContainer(MaceSkins.MOD_ID)
            .orElseThrow();

        for (String skinId : SkinManager.SKIN_IDS) {
            ResourceManagerHelper.registerBuiltinResourcePack(
                Identifier.of(MaceSkins.MOD_ID, skinId),
                container,
                Text.literal("Mace Skin — " + skinId),
                ResourcePackActivationType.NORMAL   // enabled/disabled on demand
            );
        }

        // ── 3. Tick listener: open screen when M is pressed ─────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new MaceSkinsScreen());
                }
            }
        });
    }
}
